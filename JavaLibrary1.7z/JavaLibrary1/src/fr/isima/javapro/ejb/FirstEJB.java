/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.isima.javapro.ejb;

import fr.isima.javapro.annotation.Stateless;

@Stateless
public class FirstEJB extends EJBDefaultImpl implements FirstEJBLocal {}